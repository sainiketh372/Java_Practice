package com.tcs.jfd.codes.priorityreport;

import java.util.Comparator;

public class TransactionPriorityComparator implements Comparator<Transaction>{
	
	private int getTransPriority(String transactionType) {
	switch(transactionType) {
	case "RTGS":
		return 3;
	case "IMPS":
		return 2;
	case "NEFT":
		return 1;
	default:
		return 0;
	}
	}
	@Override
	public int compare(Transaction o1, Transaction o2) {
		
		//For Transaction Type Priority Comparison
		int priorityCom1 = getTransPriority(o1.getTransactionType());
		int priorityCom2 = getTransPriority(o2.getTransactionType());
		
		if(priorityCom1!=priorityCom2) {
			return priorityCom2-priorityCom1;
		}
		
		//For Amount Type Priority Comparison
		if(o1.getAmount()!=o2.getAmount()) {
			return Double.compare(o2.getAmount(), o1.getAmount());
		}
		
		//For TimeStamp Priority Comparison 
		return Long.compare(o1.getTimestamp(), o2.getTimestamp());
	}

}
