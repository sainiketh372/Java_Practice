package com.tcs.jfd.codes.priorityreport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TransactionMain {
	public static void main(String[] args) {
		List<Transaction> trans = new ArrayList<>();
		trans.add(new Transaction("A", "NEFT", 50000.0, 100));
		trans.add(new Transaction("B", "IMPS", 50000.0, 101));
		trans.add(new Transaction("C", "RTGS", 50000.0, 102));
		Sorter(trans);
	}

	public static void Sorter(List<Transaction> trans) {
		System.out.println("Unsorted List: ");
		if (trans.isEmpty()) {
			System.out.println("[]");
		} else {
			for (Transaction t : trans) {
				System.out.println(t);
			}
		}

		Collections.sort(trans, new TransactionPriorityComparator());

		System.out.println("Sorted List: ");
		if (trans.isEmpty()) {
			System.out.println("[]");
		} else {
			for (Transaction t : trans) {
				System.out.println(t);
			}
		}
	}
}
