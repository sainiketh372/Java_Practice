package com.tcs.jfd.codes;

import java.util.Scanner;

public class ValidCodes {
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			String CodeInput = sc.nextLine();
			ValiationCodes(CodeInput);
		}
	}

	public static void ValiationCodes(String code) {
		if (code.length()!= 8 && code.length() != 11) {
			System.out.println("Input: " + code + " is INVALID: Invalid Length.");
			return;
		}

		for (int i = 0; i < code.length(); i++) {
			char charac = code.charAt(i);
			if (!Character.isLetterOrDigit(charac)) {
				System.out.println("Input: " + code + " is INVALID:" + " Contains non-alphanumeric characters.");
				return;
			}
		}

		for (int i = 0; i < 4; i++) {
			if (!Character.isLetter(code.charAt(i))) {
				System.out.println("Input:" + code + " is INVALID: Institute Code must be alphabetic.");
				return;
			}
		}

		for (int i = 4; i < 6; i++) {
			if (!Character.isLetter(code.charAt(i))) {
				System.out.println("Input:" + code + " is INVALID: Country Code must be alphabetic.");
				return;
			}
		}

		for (int i = 6; i < 8; i++) {
			if (!Character.isLetterOrDigit(code.charAt(i))) {
				System.out.println("Input:" + code + " is INVALID: Location Code contains invalid characters");
				return;
			}
		}

		if (code.length() == 11) {
			for (int i = 8; i < 11; i++) {
				if (!Character.isLetterOrDigit(code.charAt(i))) {
					System.out.println("Input:" + code + " is INVALID: Branch Code contains invalid characters");
					return;
				}
			}
		}

		System.out.println("Input: " + code + " is VALID");

	}
}
