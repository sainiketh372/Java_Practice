package com.tcs.jfd.Exception;

public class PasswordException extends Exception{

	public PasswordException(String m) {
		super(m);
	}
	
}
