package com.tcs.jfd.Exception;
import java.util.Scanner;

public class PasswordEx {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String password = sc.nextLine();
		
		ValidPassword vp = new ValidPassword();
		try {
			vp.validatePassword(password);
		}catch(PasswordException e) {
			System.err.println("Invalid Password");
		}
	}

}
