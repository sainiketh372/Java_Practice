package com.tcs.jfd.Exception;

public class ValidateUser {
	public void validate(String Username,String password) throws LoginException{
		if(Username.equals("admin") && password.equals("admin123")) {
			System.out.println("Welcome to application");
		}else {
			LoginException le = new LoginException("Invalid");
			throw le;
		}
	}

}
