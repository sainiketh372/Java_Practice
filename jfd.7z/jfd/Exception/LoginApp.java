package com.tcs.jfd.Exception;
import java.util.Scanner;

public class LoginApp {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String Username= sc.next();
		String password = sc.next();
		
		ValidateUser vu = new ValidateUser();
		try {
			vu.validate(Username,password);
		}catch(LoginException e) {
			System.err.println("Give valid credentials");
		}
	}

}
