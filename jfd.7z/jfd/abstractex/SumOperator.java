package com.tcs.jfd.abstractex;

public class SumOperator extends Operator{
	
	void ope(int a,int b) {
		System.out.println(a+b);
	}

}
