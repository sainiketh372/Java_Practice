package com.tcs.jfd.abstractex;

public class SubOperator extends Operator {
	
	void ope(int a, int b) {
		System.out.println(a-b);
	}

}
