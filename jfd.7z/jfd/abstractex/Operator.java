package com.tcs.jfd.abstractex;

public abstract class Operator {
	abstract void ope(int a,int b);

}
