package com.tcs.jfd.BankInterface;

public interface Rbi {
	void deposit();
	void withDraw();
	void displayBalance();

}
