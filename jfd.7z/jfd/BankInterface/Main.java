package com.tcs.jfd.BankInterface;

public class Main {
	public static void main(String[] args) {
		Bankabs obj;
		obj = new Icici();
		obj.deposit();
		obj.withDraw();
		obj.displayBalance();
		
		obj = new Sbi();
		obj.deposit();
		obj.withDraw();
		obj.displayBalance();
		
	}

}
