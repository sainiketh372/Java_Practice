package com.tcs.jfd.BankInterface;

public class Sbi extends Bankabs {
	public void deposit() {
		System.out.println("Min balance in sbi is 200");
	}
	public void withDraw() {
		System.out.println("Withdrawing amount is 100 in sbi");
	}
}
