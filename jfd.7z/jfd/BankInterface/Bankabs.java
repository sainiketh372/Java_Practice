package com.tcs.jfd.BankInterface;

public abstract class Bankabs implements Rbi {

	@Override
	public void displayBalance() {
		System.out.println("Your Balance is Your Balance");
		
	}

}
