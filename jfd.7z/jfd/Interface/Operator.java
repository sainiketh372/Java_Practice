package com.tcs.jfd.Interface;

public interface Operator {
	abstract void ope(int a,int b);

}
