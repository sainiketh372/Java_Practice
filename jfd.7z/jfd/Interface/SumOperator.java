package com.tcs.jfd.Interface;

public class SumOperator implements Operator{
	
	public void ope(int a,int b) {
		System.out.println(a+b);
	}

}
