package com.tcs.jfd.Interface;

public class OperatorEx {
	public static void main(String[] args) {
		Operator op;
		op = new SumOperator();
		op.ope(10, 20);
		
		op = new SubOperator();
		op.ope(10, 20);
		
	}

}
