package com.tcs.jfd.inheritance;

public class Main {
	public static void main(String[] args) {
		Student s1 = new Student("Sai", "Niketh", 34, "Hyderabad");
		s1.displayStudentDetails();
		
		Trainer t1 = new Trainer("Raju","Mantri","Chemistry",8000,"Temporary");
		t1.displayTrainerDetails();
	}

}
