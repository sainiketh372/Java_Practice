package com.tcs.jfd.abstractex1;

public class Manager extends Employee{
	public void jobs() {
		System.out.println("Observe everyone");
	}
	
	public void timings() {
		System.out.println("24hrs be Online");
	}

}
