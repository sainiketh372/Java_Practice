package com.tcs.jfd.abstractex1;

public abstract class Employee {
	abstract void jobs();
	abstract void timings();
	
	void noticePeriods() {
		System.out.println("Notice Period is 2 Months");
	}
}
