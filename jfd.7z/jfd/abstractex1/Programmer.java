package com.tcs.jfd.abstractex1;

public class Programmer extends Employee{
		public void jobs() {
			System.out.println("Apply Logic by Using Sequence Diagram");
		}
		
		public void timings() {
			System.out.println("Timings are 1:00 pm to 10:00 pm");
		}
		
}
