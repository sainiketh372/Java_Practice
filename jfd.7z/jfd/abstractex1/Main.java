package com.tcs.jfd.abstractex1;

public class Main {
	public static void main(String[] args) {
		Employee obj;
		obj = new Programmer();
		obj.jobs();
		obj.timings();
		obj.noticePeriods();
	}

}
