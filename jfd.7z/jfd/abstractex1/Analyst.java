package com.tcs.jfd.abstractex1;

public class Analyst extends Employee {
	public void jobs() {
		System.out.println("Analyse The Requirement");
	}
	
	public void timings() {
		System.out.println("Timings are 8:00 pm to 5:00 pm");
	}
}
