package com.tcs.jfd.Strings;

public class StringEx2 {
	public static boolean condition1(String s) {
		if ((s.contains("@")) && (s.contains("."))) {
			return true;
		}
		return false;
	}

	public static boolean condition2(String s) {
		return s.split("@").length == 2;
	}

	public static boolean condition3(String s) {
		String[] s1 = s.split("@");
		boolean result = s1[1].split("\\.")[0].length() >= 4;
		return result;
	}

	public static boolean condition4(String s) {
		String[] s2 = s.split("@");
		boolean res = s2[0].length() >= 3;
		return res;
	}

	public static boolean condition5(String s) {
		return s.endsWith(".com");
	}

	public static void main(String[] args) {
		String s = "Sai@tcs1.com";
		if (condition1(s) && condition2(s) && condition3(s) && condition4(s) && condition5(s)) {
			System.out.println("Valid Email");
		}else {
		System.out.println("Not Valid Email");
		}
	}

}
