package com.tcs.jfd.Strings;

public class Stringex1 {
	public static void main(String[] args) {
		String[] emails = {"abc@gmail.com","xyz@tcs.com","pqr@yahoo.com"};
		int count=0;
		for(String i : emails) {
			if(i.contains("tcs.com")) {
				count++;
			}
		}
		System.out.println("Tcs Containing mails are : " +count);
	}

}
