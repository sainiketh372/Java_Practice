package com.tcs.jfd.Strings;
import java.util.Scanner;

public class StringEx {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter an String: ");
		
		String input = sc.nextLine();
		System.out.println(input);
		StringBuffer sb = new StringBuffer(input);
		String reverse = sb.reverse().toString();
		if(reverse.equals(input)) {
			System.out.println("Is a Palindrome");
		}else {
			System.out.println("Not a Palindrome");
		}
	}

}
