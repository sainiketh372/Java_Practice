package com.tcs.jfd.Strings;



public class Ex1 {
	public void separation() {
	String s1 = "Tom:I am from Australia";
	
	
	
	String []s3 = s1.split(" ");
	String [] s4 = s3[0].split(":");
 	System.out.print(s4[0]+ " ");
	System.out.println(s3[s3.length-1]);
	}
	
	public void StrArr() {
		String [] a1 = {"arun#12#12#12","deepak#13#12#12"};
		String topPerformer = "";
		int maxmarks = 0;
		for(String s:a1) {
			String [] r = s.split("#");
			int marksObtained = 0;
			
			for(int i=r.length-1;i>0;i--) {
				int n = Integer.parseInt(r[i]);
				marksObtained+=n;
			}
			if(marksObtained>maxmarks) {
				maxmarks=marksObtained;
				topPerformer=r[0];
			}
		}
		System.out.println(topPerformer);
		
	}
	
	public void reduction() {
		String s1 = "hello";
		String s2 = "hi";
		StringBuffer sb1 = new StringBuffer("hello");
		StringBuffer sb2 = new StringBuffer("hi");
		
		if(s1.equalsIgnoreCase(s2)) {
			System.out.println(s1+s2);
		}else {
			if(sb1.length()>sb2.length()) {
				String s3 = sb1.substring(sb2.length()+1, sb1.length());
				System.out.println(s3+s2);
			}else {
				String s4 = sb2.substring(sb1.length()+1,sb2.length());
				System.out.println(s4+s1);
			}
		}
	}
	
	public void vowels() {
		int count = 0;
		String inp = "Sai Niketh";
		String r = inp.toLowerCase();
		for(char i =0;i<r.length();i++) {
			if(r.charAt(i)=='a' || r.charAt(i)=='e' || r.charAt(i)=='i' || r.charAt(i)=='o' || r.charAt(i)=='u' ) {
				count++;
			}
		}
		System.out.println(count);
	}
	
}
