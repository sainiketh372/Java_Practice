package com.tcs.jfd.Strings;

public class Main {
	public static void main(String[] args) {
		Ex1 obj = new Ex1();
		obj.separation();
		
		obj.StrArr();
		obj.reduction();
		obj.vowels();
	}

}
