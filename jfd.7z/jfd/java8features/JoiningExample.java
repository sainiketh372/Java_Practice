package com.tcs.jfd.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class JoiningExample {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("one","two","three","four");
		String res1 = list.stream().collect(Collectors.joining());
		String res2 = list.stream().collect(Collectors.joining(","));
		System.out.println(res1+"  "+res2);
		
	}

}
