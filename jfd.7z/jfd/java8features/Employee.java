package com.tcs.jfd.java8features;

public class Employee {
		private int id;
		private String name;
		private int Salary;
		private String Deptno;
		public Employee(int id, String name, int salary) {			
			this.id = id;
			this.name = name;
			this.Salary = salary;
		}
		
		public Employee(int id, String name, int salary, String deptno) {
			this(id,name,salary);
			this.Deptno = deptno;
		}

		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getSalary() {
			return Salary;
		}
		public void setSalary(int salary) {
			Salary = salary;
		}
		
		public String toString() {
			return id+" "+name+" "+Salary;
		}

		public String getDeptno() {
			return Deptno;
		}

		public void setDeptno(String deptno) {
			this.Deptno = deptno;
		}
	

}
