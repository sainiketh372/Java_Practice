package com.tcs.jfd.java8features;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupByExample {
	public static void main(String[] args) {
		List<Employee>  list = Util.getEmployeesWithDeptno();
		Map<String, List<Employee>> maps = list.stream().collect(Collectors.groupingBy(x->x.getDeptno()));
		maps.forEach((x,y)->{
			System.out.println(x+ " "+y);
		});
		System.out.println("====");
		list.stream().collect(Collectors.groupingBy(x->x.getDeptno())).forEach((x,y)->{
			System.out.println(x+" "+y);
		});
	}

}
