package com.tcs.jfd.java8features;

import java.util.Optional;

public class OptionalExample {
	public static void main(String[] args) {
		//Optional<employee> op = optional.of(object)
		//optional<employee> op = optional.empty()
		
		Optional<String> ops = Optional.empty();
		if(ops.isPresent()) {
			System.out.println("object is there");
			
		}else {
			System.out.println("object is not there");
		}
		
		Employee emp = new Employee(0,null,0);
		
		Optional<Employee> ope = Optional.of(emp);
		if(ope.isPresent()) {
			System.out.println("emp is there");
		}else {
			System.out.println("emp is not there");
		}
		
		//second way
		ope.ifPresentOrElse(x->System.out.println("emp is there"),
				()->System.out.println("emp is not there"));
		
		ope.ifPresentOrElse(x->System.out.println(x.getId()+" "+x.getName()),
				()->System.out.println("emp is not there"));
		
		Employee emp2 = null;
		Optional<Employee> ope2 = Optional.ofNullable(emp2);
		if(ope2.isPresent()) {
			System.out.println("emp is there");
		}else {
			System.out.println("emp is not there");
		}
	}

}
