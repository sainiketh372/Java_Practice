package com.tcs.jfd.java8features;

import java.util.ArrayList;
import java.util.List;

public class Util {
	public static List<Employee> getEmployee(){
		List<Employee> list = new ArrayList<>();
		list.add(new Employee(100,"Raghu",5000));
		list.add(new Employee(101,"Raga",7000));
		list.add(new Employee(102,"Modi",4000));
		list.add(new Employee(103,"Ramesh",8000));
		list.add(new Employee(104,"Shah",9000));
		list.add(new Employee(105,"Shah",6000));
		return list;
	}
	
	public static List<Employee> getEmployeesWithDeptno(){
		List<Employee> list = new ArrayList<>();
		list.add(new Employee(100,"Raghu",5000,"IT"));
		list.add(new Employee(101,"Raga",7000,"IT"));
		list.add(new Employee(102,"Modi",4000,"HR"));
		list.add(new Employee(103,"Ramesh",8000,"HR"));
		list.add(new Employee(104,"Shah",9000,"DEV"));
		list.add(new Employee(105,"Shah",6000,"Support"));
		return list;
	}

}
