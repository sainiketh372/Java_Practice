package com.tcs.jfd.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class AnyMatch {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(11,1,-1,5,3,1,41);
		list.stream().filter(x->x%2==0).forEach(System.out::println);
		boolean result = list.stream().anyMatch(x->x%2==0);
		System.out.println(result);
		
		System.out.println("Other methods");
		boolean result1 = list.stream().noneMatch(x->x%2==0);
		System.out.println(result1);
		
		int a = list.stream().findFirst().get();
		System.out.println(a);
		
		int b = list.stream().min((x,y)->x.compareTo(y)).get();
		System.out.println(b);
		
		int c = list.stream().max((x,y)->x.compareTo(y)).get();
		System.out.println(c);
		
	}

}
