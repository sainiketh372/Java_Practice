package com.tcs.jfd.java8features;

import java.util.List;
//map converts list object into one data type(List<class> object data to String/Int etc)
public class MapExample {
	public static void main(String[] args) {
		List<Employee> list = Util.getEmployee();
		
		list.stream().filter(x->x.getSalary()>5000)					
						.map(x->x.getId())
						.forEach(x->System.out.println(x));
		
		list.stream().filter(x->x.getSalary()>5000)					
						.map(x->x.getId())
						.forEach(System.out::println); //USed Reference
	}

}
