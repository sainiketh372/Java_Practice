package com.tcs.jfd.java8features;

import java.util.List;
import java.util.stream.Collectors;

public class AvgSumSalary {
	public static void main(String[] args) {
		List<Employee> list = Util.getEmployeesWithDeptno();
		Double avgSal = list.stream().collect(Collectors.averagingInt(x->x.getSalary()));
		
		Double sal = list.stream().collect(Collectors.averagingInt(x->x.getSalary()));
	}

}
