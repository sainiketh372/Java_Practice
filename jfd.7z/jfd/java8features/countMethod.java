package com.tcs.jfd.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class countMethod {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10,2,-1,5,3,1,4);
		long count = list.stream().filter(x->x%2==0).count();
		System.out.println("numbers even are: "+count);
		
		List<Integer> count1 = list.stream().filter(x->x%2==0).map(x->x*3).collect(Collectors.toList());
		System.out.println(count1);
	}

}
