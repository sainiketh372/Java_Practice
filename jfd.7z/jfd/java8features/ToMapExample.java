package com.tcs.jfd.java8features;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ToMapExample {
	public static void main(String[] args) {
		List<Employee> list = Util.getEmployee();
		Map<Integer, String> maps = list.stream().collect(Collectors.toMap(x->x.getId(),y->y.getName()));
		
		System.out.println(maps);
	}

}
