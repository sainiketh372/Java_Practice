package com.tcs.jfd.java8features;

import java.util.Arrays;
import java.util.List;

public class ReduceExample {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(11,1,-1,5,3,1,41);
		int result = list.stream().reduce((x,y)->x+y).get();
		System.out.println(result);
	}

}
