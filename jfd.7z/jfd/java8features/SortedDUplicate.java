package com.tcs.jfd.java8features;

import java.util.Comparator;
import java.util.List;

public class SortedDUplicate {
	public static void main(String[] args) {
		List<Employee> list = Util.getEmployee();
		
		System.out.println("names in ascending order");
		list.stream().map(x->x.getName()).sorted().forEach(System.out::println);
		
		
		System.out.println("names in descending order");
		list.stream().map(x->x.getName()).sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		list.stream().map(x->x.getName()).sorted((x,y)->y.compareTo(x)).forEach(System.out::println);
	}

}
