package com.tcs.jfd.java8features;

import java.util.List;
//fiter is a intermediate op and forEach is terminal op
public class FilterExample {
	public static void main(String[] args) {
		List<Employee> list = Util.getEmployee();
		list.stream().forEach(x->{
			System.out.println(x);
		});
		
		System.out.println("Employess are getting salary more than 5k");
		
		list.stream().filter(x->x.getSalary()>5000).forEach(x->System.out.println(x));
	}
}
