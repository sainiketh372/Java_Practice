package com.tcs.jfd.java8features;

import java.util.List;
import java.util.stream.Collectors;

public class CollectingList {
	public static void main(String[] args) {
		List<Employee> list = Util.getEmployee();
		
		List<String> names = list.stream().map(x-> x.getName())
				.collect(Collectors.toList());
		
		System.out.println(names.size());
		
		
		List<String> enames = list.stream().filter(x->x.getId()>103)
				.map(x-> x.getName())
				.collect(Collectors.toList());
		
		System.out.println(enames);
		
		List<String> enamesdis = list.stream().map(x-> x.getName())
				.distinct()
				.collect(Collectors.toList());
		
		System.out.println(enamesdis);
		
	}

}
