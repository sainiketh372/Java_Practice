package com.tcs.jfd.Java8Practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class practice1 {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(11,10,-1,5,30,1,4);
		List<Integer> a =list.stream().filter(x->x%2==0).collect(Collectors.toList());
		System.out.println("1) Even Numbers ");
		System.out.println(a);
		System.out.println();
		
		
		List<String> list1 = Arrays.asList("sai","nike","raju");
		List<String> r = list1.stream().map(x->x.toUpperCase()).collect(Collectors.toList());
		System.out.println("2) Strings to Uppercase ");
		System.out.println(r);
		System.out.println();
		
		List<String> list2 = Arrays.asList("sai","sai","nike","nike");
		Set<String> dup = new HashSet<>();
		List<String> v = list2.stream().filter(x->!dup.add(x)).collect(Collectors.toList());
		System.out.println("3) Duplicate Elements ");
		System.out.println(v);
		System.out.println();
		
		
		List<Integer> list3 = Arrays.asList(11,10,-1,5,30,11,4,10);
		List<Integer> b = list3.stream().filter(x->x>10).limit(1).collect(Collectors.toList());
		System.out.println("4) Greater than 10 Limit 1 ");
		System.out.println(b);
		System.out.println();
		
		
		List<Integer> list4 = Arrays.asList(11,10,-1,5,30,11,4,10);
		List<Integer> c = list4.stream().sorted((x,y)->y.compareTo(x)).collect(Collectors.toList());
		System.out.println("5) Descending order ");
		System.out.println(c);
		System.out.println();
		
		List<Integer> list5 = Arrays.asList(11,10,5,30,11,4,10);
		int d = list5.stream().reduce((x,y)->x+y).get();
		System.out.println("6) Sum of Elements ");
		System.out.println(d);
		System.out.println();
		
		
		List<String> list6 = Arrays.asList("sai","nike","raju","sai","raju");
		Map<Object, Long> e = list6.stream().collect(Collectors.groupingBy(x->x,Collectors.counting()));
		System.out.println("7) Occurence of each word ");
		System.out.println(e);
		System.out.println();
		
		List<Integer> list7 = Arrays.asList(11,10,5,30,11,40,10);
		int f = list7.stream().max((x,y)->x.compareTo(y)).get();
		System.out.println("8) Find max number ");
		System.out.println(f);
		System.out.println();
		
		List<Integer> list71 = Arrays.asList(11,10,5,30);
		List<Integer> list8 = Arrays.asList(30,11,40,10);
		Set<Integer> res = new HashSet<>();
		List<Integer> list9 = Stream.concat(list71.stream(), list8.stream()).collect(Collectors.toList());
		List<Integer> list10 = list9.stream().filter(x->res.add(x)).collect(Collectors.toList());
		System.out.println("9) Merge and remove duplicates ");
		System.out.println(list10);
		System.out.println();
		
		
		
	}

}
